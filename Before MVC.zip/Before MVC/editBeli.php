<?php
include "beli.php";

if (isset($_GET['id'])) {
    $IdPembelian = $_GET['id'];
    $barang = new Barang();
    $data_barang = $barang->getBarangById($IdPembelian);

    if (!$data_barang) {
        die("Barang tidak ditemukan.");
    }

    if (isset($_POST['submit'])) {
        $JumlahPembelian = $_POST['JumlahPembelian'];
        $HargaBeli = $_POST['HargaBeli'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->updateBarang($IdPembelian, $JumlahPembelian, $HargaBeli, $IdPengguna)) {
            echo "Barang berhasil diupdate.";
        } else {
            echo "Gagal mengupdate barang.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Barang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h2>Edit Barang</h2>

        <form method="post">
            <table width="30%">
                <tr>
                    <td>ID Pembelian :</td>
                    <td> <input type="text" name="IdPembelian" value="<?php echo $data_barang['IdPembelian']; ?>"
                            readonly></td>
                </tr>
                <tr>
                    <td> Jumlah Pembelian : </td>
                    <td><input type="number" name="JumlahPembelian"
                            value="<?php echo $data_barang['JumlahPembelian']; ?>" required></td>
                </tr>
                <tr>
                    <td> Harga beli: </td>
                    <td><input type="number" name="HargaBeli" value="<?php echo $data_barang['HargaBeli']; ?>" required>
                    </td>
                </tr>
                <tr>
                    <td> ID Pengguna: </td>
                    <td><input type="text" name="IdPengguna" value="<?php echo $data_barang['IdPengguna']; ?>" required>
                    </td>
                </tr>
                <tr>
                    <td><input type="submit" name="submit" value="Update Barang"></td>
                    <td><a href='pembelian.php'>Kembali ke Pembelian</a></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>