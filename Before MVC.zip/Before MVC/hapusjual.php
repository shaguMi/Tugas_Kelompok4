<?php
include "jual.php";

if (isset($_GET['id'])) {
    $IdPenjualan = $_GET['id'];
    $barang = new Barang();
    $data_penjualan = $barang->getBarangById($IdPenjualan);

    if (!$data_penjualan) {
        die("Data penjualan tidak ditemukan.");
    }

    if (isset($_POST['hapus'])) {
        if ($barang->hapusBarang($IdPenjualan)) {
            echo "Data penjualan berhasil dihapus.";
        } else {
            echo "Gagal menghapus data penjualan.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Hapus Data Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Hapus Data Penjualan</h2>

    <p>Apakah Anda yakin ingin menghapus data penjualan dengan ID:
        <?php echo $data_penjualan['IdPenjualan']; ?>?
    </p>

    <form method="post">
        <input type="submit" name="hapus" value="Hapus Data">
        <a href='penjualan.php'>Kembali ke Tabel Penjualan</a>
    </form>

</body>

</html>