<!DOCTYPE html>
<html>

<head>
    <title>CRUD Tabel Barang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    include "barang.php";

    $barang = new Barang();

    // Proses update barang jika form disubmit
    if (isset($_POST['update'])) {
        $IdBarang = $_POST['IdBarang'];
        $NamaBarang = $_POST['NamaBarang'];
        $Keterangan = $_POST['Keterangan'];
        $Satuan = $_POST['Satuan'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->updateBarang($IdBarang, $NamaBarang, $Keterangan, $Satuan, $IdPengguna)) {
            echo "Barang berhasil diupdate.";
        } else {
            echo "Gagal mengupdate barang.";
        }
    }

    // Proses delete barang jika parameter "hapus" terdapat di URL
    if (isset($_GET['hapus'])) {
        $IdBarang = $_GET['hapus'];

        if ($barang->hapusBarang($IdBarang)) {
            echo "Barang berhasil dihapus.";
        } else {
            echo "Gagal menghapus barang.";
        }
    }
    ?>


    <h2>Tabel Barang</h2>



    <!-- Tampilkan data barang -->
    <table>
        <tr>
            <td>
                <h3>Data Barang</h3>
            </td>
        </tr>
        <table border="1">
            <tr>
                <th>ID Barang</th>
                <th>Nama Barang</th>
                <th>Keterangan</th>
                <th>Satuan</th>
                <th>ID Pengguna</th>
                <th>Aksi</th>
            </tr>

            <?php
            $semua_barang = $barang->getSemuaBarang();
            foreach ($semua_barang as $barang) {
                echo "<tr>";
                echo "<td>" . $barang['IdBarang'] . "</td>";
                echo "<td>" . $barang['NamaBarang'] . "</td>";
                echo "<td>" . $barang['Keterangan'] . "</td>";
                echo "<td>" . $barang['Satuan'] . "</td>";
                echo "<td>" . $barang['IdPengguna'] . "</td>";
                echo "<td><a href='edit.php?id=" . $barang['IdBarang'] . "'>Edit</a> | <a href='?hapus=" . $barang['IdBarang'] . "'>Hapus</a></td>";
                echo "</tr>";
            }
            ?>
        </table>

        <table>
            <tr>
                <td><a class="button" href="pembelian.php">Masuk Ke pembelian</td>
                <td><a class="button" href="penjualan.php">Masuk Ke penjualan</td>
            </tr>
        </table>


</body>

</html>