<?php
include "koneksi.php";

class Barang
{
    // Function untuk menambahkan pembelian ke database
    public function tambahBarang($IdPembelian, $JumlahPembelian, $HargaBeli, $IdPengguna)
    {
        global $conn;
        $IdPembelian = $conn->real_escape_string($IdPembelian);
        $JumlahPembelian = (int) $JumlahPembelian;
        $HargaBeli = (int) $HargaBeli;
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "INSERT INTO pembelian (IdPembelian, JumlahPembelian, HargaBeli, IdPengguna) VALUES ('$IdPembelian', $JumlahPembelian, $HargaBeli, '$IdPengguna')";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil semua data pembelian dari database
    public function getSemuaBarang()
    {
        global $conn;

        $sql = "SELECT * FROM pembelian";
        $result = $conn->query($sql);

        $data_barang = array();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data_barang[] = $row;
            }
        }

        return $data_barang;
    }

    // Function untuk mengupdate data pembelian berdasarkan IdPembelian
    public function updateBarang($IdPembelian, $JumlahPembelian, $HargaBeli, $IdPengguna)
    {
        global $conn;
        $IdPembelian = $conn->real_escape_string($IdPembelian);
        $JumlahPembelian = (int) $JumlahPembelian;
        $HargaBeli = (int) $HargaBeli;
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "UPDATE pembelian SET JumlahPembelian=$JumlahPembelian, HargaBeli=$HargaBeli, IdPengguna='$IdPengguna' WHERE IdPembelian='$IdPembelian'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk menghapus data pembelian berdasarkan IdPembelian
    public function hapusBarang($IdPembelian)
    {
        global $conn;
        $IdPembelian = $conn->real_escape_string($IdPembelian);

        $sql = "DELETE FROM pembelian WHERE IdPembelian='$IdPembelian'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil data pembelian berdasarkan IdPembelian
    public function getBarangById($IdPembelian)
    {
        global $conn;
        $IdPembelian = $conn->real_escape_string($IdPembelian);

        $sql = "SELECT * FROM pembelian WHERE IdPembelian='$IdPembelian'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return null;
        }
    }
}
?>