<?php
include "koneksi.php";

class Barang
{
    // Function untuk menambahkan barang ke database
    public function tambahBarang($IdBarang, $NamaBarang, $Keterangan, $Satuan, $IdPengguna)
    {
        global $conn;
        $IdBarang = $conn->real_escape_string($IdBarang);
        $NamaBarang = $conn->real_escape_string($NamaBarang);
        $Keterangan = $conn->real_escape_string($Keterangan);
        $Satuan = $conn->real_escape_string($Satuan);
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "INSERT INTO barang (IdBarang, NamaBarang, Keterangan, Satuan, IdPengguna) VALUES ('$IdBarang', '$NamaBarang', '$Keterangan', '$Satuan', '$IdPengguna')";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil semua data barang dari database
    public function getSemuaBarang()
    {
        global $conn;

        $sql = "SELECT * FROM barang";
        $result = $conn->query($sql);

        $data_barang = array();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data_barang[] = $row;
            }
        }

        return $data_barang;
    }

    // Function untuk mengupdate data barang berdasarkan IdBarang
    public function updateBarang($IdBarang, $NamaBarang, $Keterangan, $Satuan, $IdPengguna)
    {
        global $conn;
        $IdBarang = $conn->real_escape_string($IdBarang);
        $NamaBarang = $conn->real_escape_string($NamaBarang);
        $Keterangan = $conn->real_escape_string($Keterangan);
        $Satuan = $conn->real_escape_string($Satuan);
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "UPDATE barang SET NamaBarang='$NamaBarang', Keterangan='$Keterangan', Satuan='$Satuan', IdPengguna='$IdPengguna' WHERE IdBarang='$IdBarang'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk menghapus data barang berdasarkan IdBarang
    public function hapusBarang($IdBarang)
    {
        global $conn;
        $IdBarang = $conn->real_escape_string($IdBarang);

        $sql = "DELETE FROM barang WHERE IdBarang='$IdBarang'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil data barang berdasarkan IdBarang
    public function getBarangById($IdBarang)
    {
        global $conn;
        $IdBarang = $conn->real_escape_string($IdBarang);

        $sql = "SELECT * FROM barang WHERE IdBarang='$IdBarang'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return null;
        }
    }
}
?>