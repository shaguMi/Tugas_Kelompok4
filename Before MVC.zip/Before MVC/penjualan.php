<!DOCTYPE html>
<html>

<head>
    <title>Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    include "jual.php";

    $barang = new Barang();

    // Proses tambah barang jika form disubmit
    if (isset($_POST['submit'])) {
        $IdPenjualan = $_POST['IdPenjualan'];
        $JumlahPenjualan = $_POST['JumlahPenjualan'];
        $HargaJual = $_POST['HargaJual'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->tambahBarang($IdPenjualan, $JumlahPenjualan, $HargaJual, $IdPengguna)) {
            echo "Data berhasil ditambahkan.";
        } else {
            echo "Gagal menambahkan data.";
        }
    }
    ?>




    <table>
        <tr>
            <h2>Tabel Penjualan</h2>
        </tr>
        <tr>
            <td>
                <a class="button" href="index.php">Kembali ke Barang</a>
            </td>


            <td>
                <a class="button" href='pembelian.php'>Masuk Ke pembelian</a>
            </td>
        </tr>


        <form method="post">
            <table width="30%">
                <tr>
                    <td>
                        <h3>Tambah Penjualan</h3>
                    </td>
                </tr>
                <tr>
                    <td>ID Penjualan:</td>
                    <td> <input type="text" name="IdPenjualan" required></td>
                </tr>
                <tr>
                    <td> Jumlah Penjualan: </td>
                    <td><input type="number" name="JumlahPenjualan" required></td>
                </tr>
                <tr>
                    <td> Harga Jual: </td>
                    <td><input type="number" name="HargaJual" required></td>
                </tr>
                <tr>
                    <td> ID Pengguna: </td>
                    <td><input type="text" name="IdPengguna" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="submit" value="Tambah Data"></td>

                </tr>
            </table>
        </form>

        <!-- Tampilkan data penjualan -->
        <table>
            <tr>
                <td>
                    <h3>Data Penjualan</h3>
                </td>
            </tr>
            <table border="1">
                <tr>
                    <th>ID Penjualan</th>
                    <th>Jumlah Penjualan</th>
                    <th>Harga Jual</th>
                    <th>ID Pengguna</th>
                    <th>Aksi</th>
                </tr>
                <?php
                $semua_data = $barang->getSemuaBarang();
                foreach ($semua_data as $data) {
                    echo "<tr>";
                    echo "<td>" . $data['IdPenjualan'] . "</td>";
                    echo "<td>" . $data['JumlahPenjualan'] . "</td>";
                    echo "<td>" . $data['HargaJual'] . "</td>";
                    echo "<td>" . $data['IdPengguna'] . "</td>";
                    echo "<td><a href='editjual.php?id=" . $data['IdPenjualan'] . "'>Edit</a> | <a href='hapusjual.php?id=" . $data['IdPenjualan'] . "'>Hapus</a></td>";
                    echo "</tr>";
                }
                ?>
            </table>

</body>

</html>