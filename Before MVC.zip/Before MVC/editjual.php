<?php
include "jual.php";

if (isset($_GET['id'])) {
    $IdPenjualan = $_GET['id'];
    $barang = new Barang();
    $data_penjualan = $barang->getBarangById($IdPenjualan);

    if (!$data_penjualan) {
        die("Data penjualan tidak ditemukan.");
    }

    if (isset($_POST['submit'])) {
        $JumlahPenjualan = $_POST['JumlahPenjualan'];
        $HargaJual = $_POST['HargaJual'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->updateBarang($IdPenjualan, $JumlahPenjualan, $HargaJual, $IdPengguna)) {
            echo "Data penjualan berhasil diupdate.";
            $data_penjualan = $barang->getBarangById($IdPenjualan); // Refresh data setelah diupdate
        } else {
            echo "Gagal mengupdate data penjualan.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Data Penjualan</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h2>Edit Data Penjualan</h2>

    <form method="post">
        <table width="30%">
            <tr>
                <td>ID Penjualan :</td>
                <td> <input type="text" name="IdPenjualan" value="<?php echo $data_penjualan['IdPenjualan']; ?>"
                        readonly></td>
            </tr>
            <tr>
                <td> Jumlah Penjualan : </td>
                <td><input type="number" name="JumlahPenjualan"
                        value="<?php echo $data_penjualan['JumlahPenjualan']; ?>" required></td>
            </tr>
            <tr>
                <td> Harga Jual: </td>
                <td><input type="number" name="HargaJual" value="<?php echo $data_penjualan['HargaJual']; ?>" required>
                </td>
            </tr>
            <tr>
                <td> ID Pengguna: </td>
                <td><input type="text" name="IdPengguna" value="<?php echo $data_penjualan['IdPengguna']; ?>" required>
                </td>
            </tr>
            <tr>
                <td><input type="submit" name="submit" value="Update Data"></td>
                <td><a href='penjualan.php'>Kembali ke Tabel Penjualan</a></td>
            </tr>
        </table>
    </form>

</body>

</html>