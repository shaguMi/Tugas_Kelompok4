<?php
include "barang.php";

if (isset($_GET['id'])) {
    $IdBarang = $_GET['id'];
    $barang = new Barang();
    $data_barang = $barang->getBarangById($IdBarang);

    if (!$data_barang) {
        die("Data barang tidak ditemukan.");
    }

    if (isset($_POST['hapus'])) {
        if ($barang->hapusBarang($IdBarang)) {
            echo "Data barang berhasil dihapus.";
        } else {
            echo "Gagal menghapus data barang.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Hapus Data Barang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Hapus Data Barang</h2>

    <p>Apakah Anda yakin ingin menghapus data barang dengan ID:
        <?php echo $data_barang['IdBarang']; ?>?
    </p>

    <form method="post">
        <input type="submit" name="hapus" value="Hapus Data">
        <a href='index.php'>Kembali ke Tabel Barang</a>
    </form>

</body>

</html>