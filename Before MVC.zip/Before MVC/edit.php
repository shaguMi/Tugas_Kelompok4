<?php
include "barang.php";

if (isset($_GET['id'])) {
    $IdBarang = $_GET['id'];
    $barang = new Barang();
    $data_barang = $barang->getBarangById($IdBarang);

    if (!$data_barang) {
        die("Data barang tidak ditemukan.");
    }

    if (isset($_POST['update'])) {
        $NamaBarang = $_POST['NamaBarang'];
        $Keterangan = $_POST['Keterangan'];
        $Satuan = $_POST['Satuan'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->updateBarang($IdBarang, $NamaBarang, $Keterangan, $Satuan, $IdPengguna)) {
            echo "Data barang berhasil diupdate.";
            $data_barang = $barang->getBarangById($IdBarang); // Refresh data setelah diupdate
        } else {
            echo "Gagal mengupdate data barang.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Edit Data Barang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
        <h2>Edit Data Barang</h2>

        <form method="post">
            <table width="50%">
                <tr>
                    <td>ID Barang :</td>
                    <td> <input type="text" name="IdBarang" value="<?php echo $data_barang['IdBarang']; ?>" readonly>
                    </td>
                </tr>
                <tr>
                    <td>Nama Barang :</td>
                    <td> <input type="text" name="NamaBarang" value="<?php echo $data_barang['NamaBarang']; ?>"
                            required></td>
                </tr>
                <tr>
                    <td>Keterangan :</td>
                    <td> <input type="text" name="Keterangan" value="<?php echo $data_barang['Keterangan']; ?>"
                            required></td>
                </tr>
                <tr>
                    <td>Satuan :</td>
                    <td> <input type="text" name="Satuan" value="<?php echo $data_barang['Satuan']; ?>" required></td>
                </tr>
                <tr>
                    <td>ID Pengguna :</td>
                    <td> <input type="text" name="IdPengguna" value="<?php echo $data_barang['IdPengguna']; ?>"
                            required></td>
                </tr>
                <tr>
                    <td><input type="submit" name="update" value="Update Data"></td>
                    <td><a href='index.php'>Kembali ke Tabel Barang</a></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>