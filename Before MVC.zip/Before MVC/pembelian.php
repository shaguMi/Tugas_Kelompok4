<!DOCTYPE html>
<html>

<head>
    <title>Pembelian</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
    include "beli.php";

    $barang = new Barang();

    // Proses tambah barang jika form disubmit
    if (isset($_POST['submit'])) {
        $IdPembelian = $_POST['IdPembelian'];
        $JumlahPembelian = $_POST['JumlahPembelian'];
        $HargaBeli = $_POST['HargaBeli'];
        $IdPengguna = $_POST['IdPengguna'];

        if ($barang->tambahBarang($IdPembelian, $JumlahPembelian, $HargaBeli, $IdPengguna)) {
            echo "Barang berhasil ditambahkan.";
        } else {
            echo "Gagal menambahkan barang.";
        }
    }
    ?>
    <table>
        <tr>
            <h2>Tabel Pembelian</h2>
        </tr>
        <tr>
            <td>
                <a class="button" href="index.php">Kembali ke Barang</a>
            </td>


            <td>
                <a class="button" href='penjualan.php'>Masuk Ke Penjualan</a>
            </td>
        </tr>


        <form method="post">
            <table width="30%">
                <tr>
                    <td>
                        <h3>Tambah Barang</h3>
                    </td>
                </tr>
                <tr>
                    <td>ID Pembelian :</td>
                    <td> <input type="text" name="IdPembelian" required></td>
                </tr>
                <tr>
                    <td> JumlahPembelian : </td>
                    <td><input type="number" name="JumlahPembelian" required></td>
                </tr>
                <tr>
                    <td> Harga beli: </td>
                    <td><input type="number" name="HargaBeli" required></td>
                </tr>
                <tr>
                    <td> ID Pengguna: </td>
                    <td><input type="text" name="IdPengguna" required></td>
                </tr>
                <tr>
                    <td></td>
                    <td><input type="submit" name="submit" value="Tambah Data"></td>

                </tr>
            </table>
        </form>


        <!-- Tampilkan data barang -->
        <table>
            <tr>
                <td>
                    <h3>Data Pembelian</h3>
                </td>
            </tr>
            <table border="1">

                <tr>
                    <th>ID Barang</th>
                    <th>Jumlah Pembelian</th>
                    <th>Harga Jual</th>
                    <th>ID Pengguna</th>
                    <th>Aksi</th>
                </tr>
                <?php
                $semua_barang = $barang->getSemuaBarang();
                foreach ($semua_barang as $barang) {
                    echo "<tr>";
                    echo "<td>" . $barang['IdPembelian'] . "</td>";
                    echo "<td>" . $barang['JumlahPembelian'] . "</td>";
                    echo "<td>" . $barang['HargaBeli'] . "</td>";
                    echo "<td>" . $barang['IdPengguna'] . "</td>";
                    echo "<td><a href='editBeli.php?id=" . $barang['IdPembelian'] . "'>Edit</a> | <a href='hapusBeli.php?id=" . $barang['IdPembelian'] . "'>Hapus</a></td>";
                    echo "</tr>";
                }
                ?>
            </table>


</body>

</html>