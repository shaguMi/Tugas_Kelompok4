<?php
include "koneksi.php";

class Barang
{
    // Function untuk menambahkan data penjualan ke database
    public function tambahBarang($IdPenjualan, $JumlahPenjualan, $HargaJual, $IdPengguna)
    {
        global $conn;
        $IdPenjualan = $conn->real_escape_string($IdPenjualan);
        $JumlahPenjualan = (int) $JumlahPenjualan;
        $HargaJual = (int) $HargaJual;
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "INSERT INTO penjualan (IdPenjualan, JumlahPenjualan, HargaJual, IdPengguna) VALUES ('$IdPenjualan', $JumlahPenjualan, $HargaJual, '$IdPengguna')";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil semua data penjualan dari database
    public function getSemuaBarang()
    {
        global $conn;

        $sql = "SELECT * FROM penjualan";
        $result = $conn->query($sql);

        $data_barang = array();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $data_barang[] = $row;
            }
        }

        return $data_barang;
    }

    // Function untuk mengupdate data penjualan berdasarkan IdPenjualan
    public function updateBarang($IdPenjualan, $JumlahPenjualan, $HargaJual, $IdPengguna)
    {
        global $conn;
        $IdPenjualan = $conn->real_escape_string($IdPenjualan);
        $JumlahPenjualan = (int) $JumlahPenjualan;
        $HargaJual = (int) $HargaJual;
        $IdPengguna = $conn->real_escape_string($IdPengguna);

        $sql = "UPDATE penjualan SET JumlahPenjualan=$JumlahPenjualan, HargaJual=$HargaJual, IdPengguna='$IdPengguna' WHERE IdPenjualan='$IdPenjualan'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk menghapus data penjualan berdasarkan IdPenjualan
    public function hapusBarang($IdPenjualan)
    {
        global $conn;
        $IdPenjualan = $conn->real_escape_string($IdPenjualan);

        $sql = "DELETE FROM penjualan WHERE IdPenjualan='$IdPenjualan'";

        if ($conn->query($sql) === TRUE) {
            return true;
        } else {
            return false;
        }
    }

    // Function untuk mengambil data penjualan berdasarkan IdPenjualan
    public function getBarangById($IdPenjualan)
    {
        global $conn;
        $IdPenjualan = $conn->real_escape_string($IdPenjualan);

        $sql = "SELECT * FROM penjualan WHERE IdPenjualan='$IdPenjualan'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            return $result->fetch_assoc();
        } else {
            return null;
        }
    }
}
?>