<?php
include "beli.php";

if (isset($_GET['id'])) {
    $IdPembelian = $_GET['id'];
    $barang = new Barang();
    $data_barang = $barang->getBarangById($IdPembelian);

    if (!$data_barang) {
        die("Barang tidak ditemukan.");
    }

    if (isset($_POST['hapus'])) {
        if ($barang->hapusBarang($IdPembelian)) {
            echo "Barang berhasil dihapus.";
        } else {
            echo "Gagal menghapus barang.";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Hapus Barang</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h2>Hapus Barang</h2>

    <p>Apakah Anda yakin ingin menghapus barang
        <?php echo $data_barang['IdPembelian']; ?>?
    </p>

    <form method="post">
        <input type="submit" name="hapus" value="Hapus Barang">
        <a href='pembelian.php'>Kembali ke Tabel Pembelian</a>
    </form>

</body>

</html>